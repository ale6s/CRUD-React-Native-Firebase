import React, { useState } from "react";
import { StyleSheet, View } from "react-native";
import { Title, Paragraph } from "react-native-paper";

function LoginScreen() {
    return (
        <View >
            <Title>Login</Title>
            <Paragraph>content</Paragraph>
        </View>
    );
}

const styles = StyleSheet.create({

});

export default LoginScreen;
